package com.dogo.chat;

import javax.persistence.*;

@Entity
@Table(name="message")

public class Message {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	private String name;
	private String content;
	
	
	//Getters
	public Integer getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	public String getContent() {
		return content;
	}
	
	
	
	
	//Setters
	public void setId(Integer id) {
		
		this.id= id;
	}
	
	public void setName(String name) {
			
			this.name= name;
	}
	
	public void setContent(String content) {
		
		this.content= content;
    }
	
}
